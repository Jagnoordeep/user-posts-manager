import React from 'react';
import { render, screen, waitFor, fireEvent } from '@testing-library/react';
import { BrowserRouter } from 'react-router-dom';
import { UserProvider } from '../context/UserContext';
import UsersList from '../Pages/UsersList';
import * as api from '../hooks/useFetch'; // Mock API

// Mock the useFetch hook
jest.mock('../hooks/useFetch', () => ({
  useFetch: jest.fn()
}));

// Mock react-confirm-alert
jest.mock('react-confirm-alert', () => ({
  confirmAlert: jest.fn()
}));

describe('UsersList', () => {
  const mockUsersData = {
    users: [
      {
        id: 1,
        firstName: 'John',
        lastName: 'Doe',
        email: 'john@example.com',
        phone: '123-456-7890',
        gender: 'male',
        birthDate: '1990-01-01'
      }
    ]
  };

  beforeEach(() => {
    jest.clearAllMocks();
    require('../hooks/useFetch').useFetch.mockReturnValue({
      data: mockUsersData,
      loading: false,
      error: null,
      refetch: jest.fn()
    });
  });

  test('renders UsersList with users data', async () => {
    render(
      <BrowserRouter>
        <UserProvider>
          <UsersList />
        </UserProvider>
      </BrowserRouter>
    );

    // Check title renders
    expect(await screen.findByText('Users Management')).toBeInTheDocument();
    
    // Check user count
    expect(screen.getByText('Users (1)')).toBeInTheDocument();
    
    // Check user name renders
    expect(screen.getByText('John Doe')).toBeInTheDocument();
    
    // Check age badge renders
    const ageBadge = screen.getByText('34');
    expect(ageBadge).toBeInTheDocument();
    expect(ageBadge).toHaveClass('bg-green-100'); // Age > 50 = green
  });

  test('shows loading spinner when loading', () => {
    require('../hooks/useFetch').useFetch.mockReturnValue({
      data: null,
      loading: true,
      error: null
    });

    render(
      <BrowserRouter>
        <UserProvider>
          <UsersList />
        </UserProvider>
      </BrowserRouter>
    );

    expect(screen.getByText('Loading users...')).toBeInTheDocument();
    expect(screen.getByTestId('spinner')).toBeInTheDocument();
  });

  test('shows error message when API fails', () => {
    require('../hooks/useFetch').useFetch.mockReturnValue({
      data: null,
      loading: false,
      error: 'Network error'
    });

    render(
      <BrowserRouter>
        <UserProvider>
          <UsersList />
        </UserProvider>
      </BrowserRouter>
    );

    expect(screen.getByText('Error')).toBeInTheDocument();
    expect(screen.getByText('Network error')).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /Retry/i })).toBeInTheDocument();
  });

  test('filters users by search term', async () => {
    render(
      <BrowserRouter>
        <UserProvider>
          <UsersList />
        </UserProvider>
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/Search by name or email/i);
    fireEvent.change(searchInput, { target: { value: 'John' } });

    await waitFor(() => {
      expect(screen.getByText('John Doe')).toBeInTheDocument();
    });
  });

  test('shows no users message when filtered results are empty', async () => {
    render(
      <BrowserRouter>
        <UserProvider>
          <UsersList />
        </UserProvider>
      </BrowserRouter>
    );

    const searchInput = screen.getByPlaceholderText(/Search by name or email/i);
    fireEvent.change(searchInput, { target: { value: 'nonexistent' } });

    await waitFor(() => {
      expect(screen.getByText('No users found matching your criteria')).toBeInTheDocument();
    });
  });

  test('delete confirmation dialog is called on delete click', async () => {
    const mockConfirmAlert = require('react-confirm-alert').confirmAlert;
    mockConfirmAlert.mockClear();

    render(
      <BrowserRouter>
        <UserProvider>
          <UsersList />
        </UserProvider>
      </BrowserRouter>
    );

    const deleteButton = screen.getByText('Delete');
    fireEvent.click(deleteButton);

    expect(mockConfirmAlert).toHaveBeenCalledWith({
      title: 'Confirm Delete',
      message: 'Are you sure you want to delete this user?',
      buttons: expect.any(Array)
    });
  });
});