import React from 'react';
import { useTranslation } from 'react-i18next';
import LanguageSwitcher from '../components/settings/LanguageSwitcher';
import NotificationToggle from '../components/settings/NotificationToggle';
import { Settings as SettingsIcon, Globe, Bell } from 'lucide-react';  // ✅ Fixed: alias SettingsIcon

const UserSettingsPage = () => {  // ✅ Renamed component to avoid conflict
  const { t } = useTranslation();

  return (
    <div className="min-h-screen bg-linear-to-br from-slate-50 via-blue-50 to-indigo-100 py-12 px-4">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <div className="text-center mb-20">
          <div className="inline-flex items-center gap-4 bg-white/60 backdrop-blur-xl px-10 py-6 rounded-3xl shadow-2xl border border-white/50">
            <SettingsIcon className="w-16 h-16 text-indigo-600 bg-indigo-100 p-4 rounded-3xl" />  {/* ✅ Use alias */}
            <div>
              <h1 className="text-5xl font-black bg-linear-to-r from-gray-900 via-indigo-900 to-purple-900 bg-clip-text text-transparent mb-3">
                {t('settings.title')}
              </h1>
              <p className="text-xl text-gray-700 font-semibold opacity-90">
                Customize your experience
              </p>
            </div>
          </div>
        </div>

        {/* Settings Sections */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-10">
          <LanguageSwitcher />
          <NotificationToggle />
        </div>

        {/* Footer */}
        <div className="mt-20 text-center">
          <button className="px-12 py-4 bg-linear-to-r from-indigo-600 to-purple-700 text-white text-lg font-bold rounded-3xl shadow-2xl hover:shadow-3xl hover:from-indigo-700 hover:to-purple-800 transition-all duration-300 transform hover:-translate-y-1">
            {t('settings.saveChanges')}
          </button>
        </div>
      </div>
    </div>
  );
};

export default UserSettingsPage;  // ✅ Export renamed component